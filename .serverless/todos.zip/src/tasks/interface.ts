export default interface Task {
    title?: string;
    description?: string;
    statusTask?: string;
  }

